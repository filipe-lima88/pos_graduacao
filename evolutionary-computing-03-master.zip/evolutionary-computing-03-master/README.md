# Exemplos de utilização de algoritmo genético, programação genética e PSO, além de otimização multi-objetivo
### Avaliação da Disciplina

<b>Julio Cesar Gonçalves Sales</b>

<b>Victor Medeiros Outtes Alves</b>

<b>Disciplina:</b> Computação Evolucionária e Inteligência de Enxames
