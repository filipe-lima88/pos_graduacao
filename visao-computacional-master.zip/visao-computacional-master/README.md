# visao-computacional
Repositorio para a disciplina de visão computacional
